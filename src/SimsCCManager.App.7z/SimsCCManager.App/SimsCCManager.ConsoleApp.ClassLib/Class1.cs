using System;

namespace SimsCCManager.App
{
    public class Class1
    {
    }
}
