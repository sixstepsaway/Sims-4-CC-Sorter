using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using SSAGlobals;
using CCSorter.Funcs;

namespace CCSorter.Controls {

    class ControlOverview
    {
        /* GAME VERSION NUMBERS ARE:

        0 = null,
        1 = Sims 1,
        2 = Sims 2,
        3 = Sims 3,
        4 = Sims 4,
        11 = Spore,
        12 = SimCity 5*/
        
        //public string ModFolder = "";
        public string logfile = "";
        //public int packageCount;
        public bool debugMode = true;
        //public int gameVer;
        //public int gameChoice;
        //LoggingGlobals logGlobals = new LoggingGlobals();
        //Package OpenPackage = new Package();
        //S2Packages s2methods = new S2Packages();
        ProcessSelectedFolder processFolder = new ProcessSelectedFolder();
        
        /*public void Initialize(int gameNum, string modLocation){
            gameChoice = gameNum;
            ModFolder = modLocation;
            logfile = modLocation + "\\SimsCCSorter.log";
            StreamWriter putContentsIntoTxt = new StreamWriter(logfile);
            putContentsIntoTxt.Close();
        }
        
        public void FindPackages(){            
            //processFolder.IdentifyPackages(ModFolder);
        }*/
    }
}