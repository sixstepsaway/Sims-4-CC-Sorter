using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using CCSorter.Controls;
using SSAGlobals;



namespace CCSorter.Funcs {
    class ProcessSelectedFolder {
        
        //string packageExtension = "package";
        //public List<FileInfo> allPackages = new List<FileInfo>();
        //public List<FileInfo> notPackages = new List<FileInfo>();
        //public string filename = "";
        //ControlOverview appInputInformation = new ControlOverview();
        LoggingGlobals logGlobals = new LoggingGlobals();
        
        /*
        public void IdentifyPackages(string ModFolder){
            foreach (string file in files) {
                FileInfo packageFile = new FileInfo(file);
                if (packageExtension.Any(packageFile.Extension.Contains)) {
                    allPackages.Add(packageFile);
                } else {
                    notPackages.Add(packageFile);
                }
            }
        }

        void GetTypeOf<T>(T LineType) {
            Console.WriteLine(typeof(T));
        }*/
    }
}